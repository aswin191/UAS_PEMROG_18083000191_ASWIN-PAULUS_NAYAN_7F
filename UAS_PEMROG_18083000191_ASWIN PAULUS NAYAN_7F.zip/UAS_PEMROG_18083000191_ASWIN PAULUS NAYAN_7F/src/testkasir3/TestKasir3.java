/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testkasir3;

/**
 *
 * @author hendra
 */
public class TestKasir3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Kasir a = new Kasir();
        a.setVisible(true);
    }
    
}
